hist(rnorm(1000))
x <- 1
