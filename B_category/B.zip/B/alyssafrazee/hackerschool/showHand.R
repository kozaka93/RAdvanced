# print mehod for a hand

showHand = function(hand){
  for(i in 1:length(hand)){
    print(hand[[i]])
  }
}
