#' R500
#'
#' @name R500
#' @docType package
NULL