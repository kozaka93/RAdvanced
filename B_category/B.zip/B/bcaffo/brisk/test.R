##this function is just for testing out code
library(AnalyzeFMRI)
getImageInfo("getImageInfo.R")
getImageInfo("../data/rest_res2standard.nii")





