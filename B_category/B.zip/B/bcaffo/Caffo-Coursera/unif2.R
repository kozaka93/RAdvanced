

xvals <- seq(-.5, 1.5, by = .001)
yvals <- rep(0, length(xvals))
yvals[xvals > 0 & xvals < 1] <- 1





