dat <- read.table("death.dat")
names(dat) <- c("BLACKD", "WHITVIC", "V4CPTY", "V5DPTY",
                "PTDTHRC", "SESF1", "POOLADEH", "POOLGBF",
                "POOLMCG", "POOMABEF", "OTHAGG")

