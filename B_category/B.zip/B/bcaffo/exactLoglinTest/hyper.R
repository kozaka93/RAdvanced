hyper <- function(y)
  sum(-lgamma(y + 1))
