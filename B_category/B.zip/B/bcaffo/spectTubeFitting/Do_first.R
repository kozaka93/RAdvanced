

file.edit("ProcessImage.R")

library(stats)
library(graphics)
library(AnalyzeFMRI)
library(splines)
library(rgl)
library(scatterplot3d)





#utils:::menunIstallPkgs()

#look for 
# AnalyzeFMRI
# rgl
# Scatterplot3d
 
