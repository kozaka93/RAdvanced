model = "elo_chess"

source("team_statistics.R")
