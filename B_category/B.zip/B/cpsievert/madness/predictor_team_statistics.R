model = "predictor"

source("team_statistics.R")
