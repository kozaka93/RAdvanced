install.packages(c("glue", "lubridate", "plotly", "purrrlyr",  "sessioninfo"))
devtools::install_github(c("tidyverse/ggplot2", "PMassicotte/gtrendsR", "Ironholds/pageviews", "dgrtwo/fuzzyjoin"))
