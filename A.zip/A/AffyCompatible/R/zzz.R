xmlValue.XMLAttributeValue <-

    function(x, ignoreComments=FALSE, recursive=TRUE,
             encoding=XML:::CE_NATIVE, trim=FALSE)

{
    as.character(x)
}
